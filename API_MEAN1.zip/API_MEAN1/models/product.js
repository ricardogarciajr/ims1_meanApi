
// Dependencies
var restful = require('node-restful');
var mongoose = restful.mongoose;

// Schema
var productSchema = new mongoose.Schema({
    sys_id: String,
    u_next_inspection_date: String,
    last_inspection_performed: String,
    asset_tag: String
});

// Return model
module.exports = restful.model('Imssmall', productSchema);
/************************************************************/
// ** collection name will become imssmalls NOT imssmall !!!!
/************************************************************/

//nested Schema
/*
var TaskSchema = new Schema({
  name: {
    type: String,
    Required: 'Kindly enter the name of the task'
  },
  Created_date: {
    type: Date,
    default: Date.now
  },
  status: {
    type: [{
      type: String,
      enum: ['pending', 'ongoing', 'completed']
    }],
    default: ['pending']
  }
});
*/
//module.exports = restful.model('Products', productSchema); //orig
//var Team = mongoose.model( "Team", teamSchema );
//module.exports = restful.model('Tasks', TaskSchema);
