
// Dependencies
var express = require('express');
var router = express.Router();

//Product
var Product = require('../models/product');
Product.methods(['get', 'put', 'post', 'delete']);
//Product.register(router, '/products'); //orig
Product.register(router, '/imssmall');

// Return router
module.exports = router;
